# QuanLauncher — catatan modifikasi

Ini adalah rebranding dari source project LeviLaunchroid yang diberikan pengguna.

## Yang diubah
- Nama aplikasi pada resource string lokal menjadi **QuanLauncher**.
- Palet warna menjadi gaya **comic-book/pop-art** dengan hijau Minecraft, kuning terang, merah sebagai aksen, dan garis gelap.
- Palet mode gelap disesuaikan agar tetap kontras.
- ID aplikasi (`org.levimc.launcher`) sengaja tidak diubah agar referensi internal dan integrasi yang sudah ada tidak rusak. Karena itu, ini rebranding tampilan/nama, bukan identitas package baru.

## Build APK
1. Ekstrak ZIP.
2. Buka folder `LeviLaunchroid-main` di Android Studio.
3. Gunakan JDK 21 atau lebih baru dan pasang Android SDK/NDK yang diminta Gradle.
4. Pastikan Git submodule terisi. Dari terminal di folder proyek jalankan:
   ```bash
   git submodule update --init --recursive
   ```
   Jika source ZIP tidak menyertakan metadata Git, clone repository asal terlebih dahulu lalu terapkan perubahan ini, atau ambil dua submodule sesuai URL di `.gitmodules`.
5. Sinkronkan Gradle, lalu jalankan task `assembleDebug`.
   - Linux/macOS: `./gradlew assembleDebug`
   - Windows: `gradlew.bat assembleDebug`
6. APK debug biasanya berada di `app/build/outputs/apk/debug/`.

## Catatan
- ZIP ini berisi source code, bukan APK yang sudah dibangun. APK belum diverifikasi dengan build penuh di lingkungan ini.
- Tampilan warna dan nama sudah direbrand; perubahan ini belum mengganti seluruh layout menjadi ilustrasi komik lengkap.
- Pertahankan file LICENSE dan pemberitahuan atribusi upstream sesuai lisensi proyek.
